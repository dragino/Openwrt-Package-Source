def getpreferredencoding():
    return "utf-8"
