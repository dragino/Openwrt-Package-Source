# this test for the availability of native emitter
@micropython.native
def f():
    pass
