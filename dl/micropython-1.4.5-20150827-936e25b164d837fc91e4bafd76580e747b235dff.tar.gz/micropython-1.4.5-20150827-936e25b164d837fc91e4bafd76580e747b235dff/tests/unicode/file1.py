f = open("unicode/data/utf-8_1.txt", encoding="utf-8")
l = f.readline()
print(l)
print(len(l))
