for c in "Hello":
    print(c)
for c in "Привет":
    print(c)
