# test builtin chr with unicode characters

print(chr(945))
print(chr(0x800))
print(chr(0x10000))
