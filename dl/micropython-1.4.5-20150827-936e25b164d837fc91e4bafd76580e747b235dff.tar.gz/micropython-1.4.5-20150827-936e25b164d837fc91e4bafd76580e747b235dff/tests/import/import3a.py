from import1b import *
print(var)
