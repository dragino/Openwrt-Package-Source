try:
    from . import foo
except:
    print("Invalid relative import caught")
