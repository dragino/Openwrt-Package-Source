import import1b
print(import1b.__file__)
