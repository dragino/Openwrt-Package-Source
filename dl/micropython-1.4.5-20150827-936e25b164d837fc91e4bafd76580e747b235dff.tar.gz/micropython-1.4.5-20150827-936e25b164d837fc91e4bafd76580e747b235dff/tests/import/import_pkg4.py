# Testing that "recursive" imports (pkg2/__init__.py imports from pkg2) work
import pkg2
