print("subpkg1.mod1 __name__:", __name__)
from ..mod2 import foo
