print("subpkg1 __name__:", __name__)
