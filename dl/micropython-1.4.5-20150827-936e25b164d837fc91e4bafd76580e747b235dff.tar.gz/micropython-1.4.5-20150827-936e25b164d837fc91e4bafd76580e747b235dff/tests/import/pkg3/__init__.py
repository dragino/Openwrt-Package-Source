print("pkg __name__:", __name__)
