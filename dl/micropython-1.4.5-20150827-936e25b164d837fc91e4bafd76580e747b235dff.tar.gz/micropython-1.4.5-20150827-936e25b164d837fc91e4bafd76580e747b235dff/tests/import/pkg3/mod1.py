print("mod1 __name__:", __name__)
from . import mod2
