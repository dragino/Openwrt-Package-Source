print("mod2 __name__:", __name__)
print("in mod2")

def foo():
    print("mod2.foo()")
