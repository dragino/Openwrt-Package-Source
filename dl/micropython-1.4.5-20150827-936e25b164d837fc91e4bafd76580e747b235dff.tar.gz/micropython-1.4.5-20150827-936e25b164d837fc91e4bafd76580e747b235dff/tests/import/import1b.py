var = 123

def throw():
    raise ValueError
