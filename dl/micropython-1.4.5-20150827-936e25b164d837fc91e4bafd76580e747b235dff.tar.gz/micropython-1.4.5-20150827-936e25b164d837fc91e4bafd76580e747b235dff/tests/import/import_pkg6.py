# This tests relative imports as used in pkg6
import pkg6
