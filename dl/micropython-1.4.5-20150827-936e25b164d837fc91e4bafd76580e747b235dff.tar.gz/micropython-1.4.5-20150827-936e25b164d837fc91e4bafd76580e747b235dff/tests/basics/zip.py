print(list(zip()))
print(list(zip([1], {2,3})))
