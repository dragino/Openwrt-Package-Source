print("".lower())
print(" t\tn\nr\rv\vf\f".upper())
print(" T E S T".lower())
print("*@a1b2cabc_[]/\\".upper())
