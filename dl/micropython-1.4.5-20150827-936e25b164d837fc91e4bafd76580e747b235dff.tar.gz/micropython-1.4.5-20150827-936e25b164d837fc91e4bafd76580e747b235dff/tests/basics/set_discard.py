s = {1, 2}
print(s.discard(1))
print(list(s))
