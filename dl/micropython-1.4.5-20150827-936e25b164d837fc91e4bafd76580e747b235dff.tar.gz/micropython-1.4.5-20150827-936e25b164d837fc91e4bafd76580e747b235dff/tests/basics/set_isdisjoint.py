s = {1, 2, 3, 4}
print(s.isdisjoint({1}))
print(s.isdisjoint([2]))
print(s.isdisjoint([]))
print(s.isdisjoint({7,8,9,10}))
print(s.isdisjoint([7,8,9,1]))
