# test builtin hex function

print(hex(1))
print(hex(-1))
print(hex(15))
print(hex(-15))

print(hex(12345))
print(hex(0x12345))

print(hex(12345678901234567890))
print(hex(0x12345678901234567890))
