a = []
for i in range(100):
    a.append(i)
    a.reverse()
print(a)
