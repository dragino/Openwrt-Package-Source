# lambda

f = lambda x, y: x + 3 * y
print(f(3, 5))
