class A():
    pass
