print(0 | (1 << 80))

a = 0xfffffffffffffffffffffffffffff
print(a | (1 << 200))
