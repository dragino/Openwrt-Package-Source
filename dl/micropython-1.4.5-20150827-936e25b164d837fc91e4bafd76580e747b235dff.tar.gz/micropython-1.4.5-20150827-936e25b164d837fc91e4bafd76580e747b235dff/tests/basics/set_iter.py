s = {1, 2, 3, 4}
l = list(s)
l.sort()
print(l)

