# test builtin object()

# creation
object()

# printing
print(repr(object())[:7])
