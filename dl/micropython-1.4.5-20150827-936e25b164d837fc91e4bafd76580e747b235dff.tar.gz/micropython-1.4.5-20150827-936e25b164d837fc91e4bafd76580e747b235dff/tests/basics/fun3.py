# function with large number of arguments

def fun(a, b, c, d, e, f, g):
    return a + b + c * d + e * f * g

print(fun(1, 2, 3, 4, 5, 6, 7))
