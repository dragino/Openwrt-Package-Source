# basic sets

s = {1}
print(s)

s = {3, 4, 3, 1}
print(sorted(s))
